#ifndef APP_POWER_H
#define APP_POWER_H

#include "cmsis_os.h"

void StartPowerTask(void const * argument);

extern osThreadId powerTaskHandle;

#endif // APP_POWER_H