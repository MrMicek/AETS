// Power monitor task: supply voltage monitoring, emergency EEPROM save
#include "app_power.h"
#include "cmsis_os.h"

void StartPowerTask(void const * argument)
{
    for(;;)
    {
        // TODO: Monitor supply voltage, trigger emergency save if low
        osDelay(100);
    }
}