/*
 * performance.c
 *
 *  Created on: 2023
 *      Author: Standa
 */

#include "performance.h"
#include "stm32g4xx_hal.h"
#include "tim.h"
#include "utility.h"

#define PERF_SUPERLOOP_FREQ_EVAL_MS		1000	// Keep at 1000 ms to have correct frequency calculation. If other value is changed, LastEvaluatedFreq_Hz formula needs to be implemented

static uint32_t LastEvalTimeStamp = 0;
static uint32_t TickCnt = 0;
static uint32_t LastEvaluatedFreq_Hz = 0;	// This value represents frequency of repetition of super loop. If it drops below 1000 Hz something is likely wrong


perf_DurTd perf_Leds = {0}, perf_ComUser = {0}, perf_ComEmc = {0}, perf_CanFd = {0}, perf_Diag = {0}, perf_SuperLoop = {0};
static perf_DurTd* Durations[] = {&perf_Leds, &perf_ComUser, &perf_ComEmc, &perf_CanFd, &perf_Diag, &perf_SuperLoop};


/*
 * Initialize performance evaluation module
 */
void perf_Init(void){

}


/*
 * Starts the performance counter for defined duration handle.
 */
void perf_StartTmr(perf_DurTd* handle){
	if(handle == 0) return;

	HAL_TIM_Base_Stop(&htim2);			// Stop the timer in case it is already running (this would be a mistake in usage anyway, some error handling may be needed in the future)
	__HAL_TIM_SetCounter(&htim2, 0);	// Reset the timer counter
	HAL_TIM_Base_Start(&htim2);			// Start the counter again
}


/*
 * Stops the performance counter for defined handle and evaluated min/max.
 */
void perf_StopTmr(perf_DurTd* handle){
	if(handle == 0) return;

	HAL_TIM_Base_Stop(&htim2);											// Stop the timer in case it is already running (this would be a mistake in usage anyway, some error handling may be needed in the future)
	handle->LastDuration_Ticks = __HAL_TIM_GetCounter(&htim2);			// Just save duration (number of ticks) between calling start and stopp

	if(handle->LastDuration_Ticks > handle->TmpMax_Ticks){				// Maintain minimum and maximum temporary values
		handle->TmpMax_Ticks = handle->LastDuration_Ticks;
	}
	else if(handle->LastDuration_Ticks < handle->TmpMin_Ticks){
		handle->TmpMin_Ticks = handle->LastDuration_Ticks;
	}

}


/*
 * Stores temporary min/max values to measurement results evaluated typically 1000ms periodicity.
 */
static void EvalStats(void){
	for(int32_t i=0; i<UT_SIZEOFARRAY(Durations); i++){
		Durations[i]->MinDuration_Ticks = Durations[i]->TmpMin_Ticks;
		Durations[i]->MaxDuration_Ticks = Durations[i]->TmpMax_Ticks;
	}
}


/*
 * Resets temporary min/max values.
 */
static void ResetStats(void){
	for(int32_t i=0; i<UT_SIZEOFARRAY(Durations); i++){
		Durations[i]->TmpMin_Ticks = UINT32_MAX;
		Durations[i]->TmpMax_Ticks = 0;
	}
}


/*
 * Will increment simple counter. Each second the counter will be reset.
 * Also should evaluate maximum duration of each major task in superloop.
 */
void perf_UpdateStats(void){
	TickCnt++;
	if(HAL_GetTick() >= LastEvalTimeStamp + PERF_SUPERLOOP_FREQ_EVAL_MS){
		LastEvalTimeStamp = HAL_GetTick();
		LastEvaluatedFreq_Hz = TickCnt;
		TickCnt = 0;

		EvalStats();
		ResetStats();
	}
}
