/*
 * diagnostics.c
 *
 *  Created on: Oct 18, 2023
 *      Author: uiv10467
 */


/*
 * diagnostics.c
 *
 *  Created on: Oct 13, 2023
 *      Author: Vojta
 */

#include "diagnostics.h"
#include "error.h"
#include "adc_INTERNAL.h"
#include <stdint.h>
#include "pwm.h"
#include "dac_ltc2633.h"
#include "utility.h"
#include "leds.h"
#include "canfd.h"
#include "fdcan.h"

#define CHECK_250mV_HIGH		350
#define CHECK_250mV_LOW			150
#define CHECK_3750mV_HIGH		3850
#define CHECK_3750mV_LOW		3650
#define CHECK_5000mV_HIGH		5500
#define CHECK_5000mV_LOW		4500
#define TIME_CONSTANT_MS		130
#define TIME_CAN_CONSTANT_MS    100
#define DIAG_PWM_FREQ_KHZ		50
#define DIAG_PWM_VOLTAGE_V		0

#define DAC_DEFAULT_VOLTAGE_mV  50
#define PWM_DEFAULT_VOLTAGE_mV	-0.1
#define PWM_DEFAULT_FREQUENCY_kHz 0

#define ERR_FLAG_CHA	(1 << 2)
#define ERR_FLAG_CHB	(1 << 3)
#define ERR_FLAG_PWM	(1 << 4)
#define ERR_FLAG_VBUS	(1 << 0)
#define ERR_FLAG_LABCOM	(1 << 1)
#define ERR_FLAG_CAN    (1 << 5)


static uint8_t err;
FDCAN_ProtocolStatusTypeDef CanStatus = {0};

void diag_Init(void){
	er_Reset();
}


void diag_RunSingleDiagnostics(void){
	//TOTAL TIME CAME TO 524 ms!
	// Total time should be below 1s
	// May be blocking as this should only be called during initialization phase before superloop starts
	leds_Set(&leds_Error);
	err = 0;

	if(diag_DAC()==err_Td_Ok)
		leds_Set(&leds_Analog);
	else
		leds_Reset(&leds_Analog);

	if(diag_PWM()==err_Td_Ok)
		leds_Set(&leds_PWM);
	else
		leds_Reset(&leds_PWM);

	/*if(diag_LabCom()!=err_Td_Ok){
		leds_Blink(&leds_Error, 1000);
		leds_Blink(&leds_Analog, 1000);
		leds_Blink(&leds_CAN, 1000);
		leds_Blink(&leds_PWM, 1000);
	}*/

	if(diag_CAN() == err_Td_Ok)
		leds_Set(&leds_CAN);
	else
		leds_Reset(&leds_CAN);

	if(diag_VBUS()!=err_Td_Ok)
		leds_Blink(&leds_Error, 1000);


	leds_Reset(&leds_Error);

	if (err & 1)
		leds_Blink(&leds_Error, 1000);

	setDiagnosticsByte(err);
	// Set respective bits in error register (error.c)
	// Enable corresponding lights

	// When diagnostics is active, red led should be on and other leds should be green
	// When diag finished and no issue, red turns off and other leds go green
	// If there is issue with some output, red led is on and problematic output led is off

	// Todo think about what to do with leds for user serial port (activate when user connects notebook) and CAN (toggle each broadcast???) and lab serial port (toggle setate when serial data was decoded)
}

// Check PWM outputs
		// Set rather high PWM frequency and 5% duty cycle
		// Read analog voltage by MCU ADC...
		// Compare read value by MCU with set value (expected 0.05*5V due to low pass filter in MCU ADC path). Tolence to be calculated by Vojta, but Im expecting also +-0.1V
err_Td diag_PWM(void){
	pwm_Calc(DIAG_PWM_VOLTAGE_V, DIAG_PWM_FREQ_KHZ);
	HAL_Delay(TIME_CONSTANT_MS);
	if(UT_VALINRANGE(adc_Read_Voltage_mV(adc_PWM),CHECK_250mV_LOW,CHECK_250mV_HIGH)){
		pwm_Calc(PWM_DEFAULT_VOLTAGE_mV, PWM_DEFAULT_FREQUENCY_kHz);
		return err_Td_Ok;
	}

	else{
		er_SetErrors(ER_PWM_DIAG_FAIL);
		err |= ERR_FLAG_PWM;
		return err_Td_NotValid;
	}
}

// Check both analog outputs
		// Set 0.25V voltage and wait till it stabilizes (approx 10x time constant of output filter)
		// Read the voltage by MCU ADC
		// Set 3.75V, wait, read MCU ADC
		// Compare read out values with set values (use reasonable tolerance... Vojta to calculate accuracy of DAC, accuracy of MCU ADC and divider).
		// My guess is tolerance to pass diagnostics is +-0.1V
err_Td diag_DAC(void){
	dac_ltc2633_SetVoltage(dac_Td_ChAll,250);
	HAL_Delay(TIME_CONSTANT_MS);
	uint32_t ChA_Low = adc_Read_Voltage_mV(adc_DAC_ChA);
	uint32_t ChB_Low = adc_Read_Voltage_mV(adc_DAC_ChB);

	dac_ltc2633_SetVoltage(dac_Td_ChAll,3750);
	HAL_Delay(TIME_CONSTANT_MS);
	uint32_t ChA_High = adc_Read_Voltage_mV(adc_DAC_ChA);
	uint32_t ChB_High = adc_Read_Voltage_mV(adc_DAC_ChB);

	if(!(UT_VALINRANGE(ChA_Low,CHECK_250mV_LOW,CHECK_250mV_HIGH)  && UT_VALINRANGE(ChA_High,CHECK_3750mV_LOW,CHECK_3750mV_HIGH))){
		er_SetErrors(ER_DACA_DIAG_FAIL);
		err |= ERR_FLAG_CHA;
		return err_Td_NotValid;
	}
	else if(!(UT_VALINRANGE(ChB_Low,CHECK_250mV_LOW,CHECK_250mV_HIGH)  && UT_VALINRANGE(ChB_High,CHECK_3750mV_LOW,CHECK_3750mV_HIGH))){
		er_SetErrors(ER_DACB_DIAG_FAIL);
		err |= ERR_FLAG_CHB;
		return err_Td_NotValid;
	}
	else {
		dac_ltc2633_SetVoltage(dac_Td_ChAll,DAC_DEFAULT_VOLTAGE_mV);
		return err_Td_Ok;
	}

}

// Read USB 5V voltage and make sure it is 4.5 to 5.5V
err_Td diag_VBUS(void){
	HAL_Delay(TIME_CONSTANT_MS);
	uint32_t VBUS_Value = adc_Read_Voltage_mV(adc_VBUS);
	if(VBUS_Value < CHECK_5000mV_LOW){
		er_SetErrors(ER_USB_UNDERVOLTAGE);
		err |= ERR_FLAG_VBUS;
		return err_Td_NotValid;
	}
	else if(VBUS_Value > CHECK_5000mV_HIGH){
		er_SetErrors(ER_USB_OVERVOLTAGE);
		err |= ERR_FLAG_VBUS;
		return err_Td_NotValid;
	}
	else
		return err_Td_Ok;
}
err_Td diag_CAN(void){
	HAL_FDCAN_GetProtocolStatus(&hfdcan2, &CanStatus);

	if(CanStatus.LastErrorCode == 0)
		return err_Td_Ok;
	else{
		err |= ERR_FLAG_CAN;
		return err_Td_Nack;
	}


}
err_Td diag_LabCom(void){
	//err |= ERR_FLAG_LABCOM;
	return err_Td_Ok;
}
