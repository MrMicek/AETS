/*
 * AppInfo.h
 *
 *  Created on: 2023
 *      Author: Vojta
 */

#ifndef APPINFO_H_
#define APPINFO_H_


#define APPINFO_COMPANY	"Vitesco_Technologies_Czech_Republic_s.r.o."
#define APPINFO_AUTHOR		"VojtechMicek"
#define APPINFO_DEVICE		"EMC_communication_converter"
#define APPINFO_HWVER		"RevA"
#define APPINFO_FWVER		"0.0"
#define APPINFO_ID			"1"
#define APPINFO_CALDATE	"20230928"


/*
 * VERSION LOG - syntax below is major.minor
 *
 * 0.0: Initial version, cubemx project created
 *
 */






#endif /* APPINFO_H_ */
