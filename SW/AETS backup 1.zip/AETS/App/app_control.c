// Main control task: handles state machine, mode switching, test orchestration
#include "app_control.h"
#include "cmsis_os.h"
#include "app_ui.h"
#include "app_relay.h"
#include "app_current.h"
#include "app_eeprom.h"
#include "app_comm.h"
#include "app_power.h"

// State machine states
typedef enum {
    SYS_STATE_INIT = 0,
    SYS_STATE_MANUAL,
    SYS_STATE_REMOTE,
    SYS_STATE_TEST_SETUP,
    SYS_STATE_TEST_EXEC,
    SYS_STATE_TEST_COMPLETE
} SystemState_t;

static SystemState_t systemState = SYS_STATE_INIT;

// Main control task function
void StartControlTask(void const * argument)
{
    // Initialization state
    systemState = SYS_STATE_INIT;
    // ... perform initialization, e.g., check voltage, read EEPROM, etc.
    // Signal UI (buzzer) when done
    app_ui_signal_init_done();
    systemState = SYS_STATE_MANUAL;

    for(;;)
    {
        switch(systemState) {
            case SYS_STATE_MANUAL:
                // Wait for user input or remote command
                if(app_comm_remote_command_received()) {
                    systemState = SYS_STATE_REMOTE;
                } else if(app_ui_manual_test_requested()) {
                    systemState = SYS_STATE_TEST_SETUP;
                }
                break;
            case SYS_STATE_REMOTE:
                // Wait for remote test setup
                if(app_comm_test_setup_received()) {
                    systemState = SYS_STATE_TEST_SETUP;
                }
                break;
            case SYS_STATE_TEST_SETUP:
                // Setup test parameters
                app_relay_prepare_test();
                app_current_prepare_test();
                systemState = SYS_STATE_TEST_EXEC;
                break;
            case SYS_STATE_TEST_EXEC:
                // Run the test
                app_relay_run_test();
                app_current_monitor_test();
                // ... check for test complete or error
                if(app_relay_test_complete()) {
                    systemState = SYS_STATE_TEST_COMPLETE;
                }
                break;
            case SYS_STATE_TEST_COMPLETE:
                // Store results, update EEPROM
                app_eeprom_update_lifetime();
                // Notify UI/comm
                app_ui_notify_test_complete();
                app_comm_send_test_result();
                // Return to previous mode
                systemState = SYS_STATE_MANUAL;
                break;
            default:
                systemState = SYS_STATE_INIT;
                break;
        }
        osDelay(10);
    }
}