/*
 * diagnostics.h
 *
 *  Created on: Oct 18, 2023
 *      Author: Vojta
 */


#ifndef DIAGNOSTICS_H_
#define DIAGNOSTICS_H_

#include "error.h"
#include "stm32g4xx_hal.h"

extern void diag_RunSingleDiagnostics(void);
extern void diag_Init(void);
extern err_Td diag_PWM(void);
extern err_Td diag_DAC(void);
extern err_Td diag_VBUS(void);
extern err_Td diag_CAN(void);
extern err_Td diag_LabCom(void);
#endif /* DIAGNOSTICS_H_ */
