/*
 * performance.h
 *
 *  Created on: 2023
 *      Author: Standa
 */

#ifndef PERFORMANCE_H_
#define PERFORMANCE_H_


#include <stdint.h>



typedef struct{
	//Results
	uint32_t LastDuration_Ticks;
	uint32_t MinDuration_Ticks;
	uint32_t MaxDuration_Ticks;
	//Temporary variables
	uint32_t TmpMin_Ticks;
	uint32_t TmpMax_Ticks;

} perf_DurTd;


extern perf_DurTd perf_Leds, perf_ComUser, perf_ComEmc, perf_CanFd, perf_Diag, perf_SuperLoop;


extern void perf_Init(void);

extern void perf_StartTmr(perf_DurTd* handle);
extern void perf_StopTmr(perf_DurTd* handle);

extern void perf_UpdateStats(void);


#endif /* PERFORMANCE_H_ */
