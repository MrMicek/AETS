// UI task: handles encoder, display, buzzer
#include "app_ui.h"
#include "cmsis_os.h"

void app_ui_signal_init_done(void) {
    // TODO: Implement buzzer signal for init done
}

int app_ui_manual_test_requested(void) {
    // TODO: Check encoder/button for manual test request
    return 0;
}

void app_ui_notify_test_complete(void) {
    // TODO: Implement UI notification for test complete
}

void StartUITask(void const * argument)
{
    for(;;)
    {
        // TODO: Handle encoder, display, buzzer events
        osDelay(20);
    }
}