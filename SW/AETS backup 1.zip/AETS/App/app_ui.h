#ifndef APP_UI_H
#define APP_UI_H

#include "cmsis_os.h"

void StartUITask(void const * argument);
void app_ui_signal_init_done(void);
int app_ui_manual_test_requested(void);
void app_ui_notify_test_complete(void);

extern osThreadId uiTaskHandle;

#endif // APP_UI_H