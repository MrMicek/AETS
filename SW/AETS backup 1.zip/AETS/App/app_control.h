#ifndef APP_CONTROL_H
#define APP_CONTROL_H

#include "cmsis_os.h"

extern osThreadId controlTaskHandle;

void StartControlTask(void const * argument);

#endif // APP_CONTROL_H