################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/AppDrv/pwm.c 

OBJS += \
./Core/Src/AppDrv/pwm.o 

C_DEPS += \
./Core/Src/AppDrv/pwm.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/AppDrv/%.o Core/Src/AppDrv/%.su Core/Src/AppDrv/%.cyclo: ../Core/Src/AppDrv/%.c Core/Src/AppDrv/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G474xx -DSTM32_THREAD_SAFE_STRATEGY=4 -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../Core/ThreadSafe -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src-2f-AppDrv

clean-Core-2f-Src-2f-AppDrv:
	-$(RM) ./Core/Src/AppDrv/pwm.cyclo ./Core/Src/AppDrv/pwm.d ./Core/Src/AppDrv/pwm.o ./Core/Src/AppDrv/pwm.su

.PHONY: clean-Core-2f-Src-2f-AppDrv

