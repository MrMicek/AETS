Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal.h \
 ../Core/Inc/stm32g4xx_hal_conf.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g474xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_cortex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_adc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_ll_adc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_adc_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_exti.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_fdcan.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pcd.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_ll_usb.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pcd_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim_ex.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 ../Core/Inc/adc.h ../Core/Inc/main.h ../Core/Inc/dma.h \
 ../Core/Inc/fdcan.h ../Core/Inc/i2c.h ../Core/Inc/spi.h \
 ../Core/Inc/tim.h ../Core/Inc/usb.h ../Core/Inc/gpio.h \
 C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/pwm.h \
 C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/App/error.h \
 C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/app_relay.h \
 C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/app_current.h
../Core/Inc/main.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal.h:
../Core/Inc/stm32g4xx_hal_conf.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g474xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_cortex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_adc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_ll_adc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_adc_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_exti.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_fdcan.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ramfunc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pcd.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_ll_usb.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pcd_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim_ex.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
../Core/Inc/adc.h:
../Core/Inc/main.h:
../Core/Inc/dma.h:
../Core/Inc/fdcan.h:
../Core/Inc/i2c.h:
../Core/Inc/spi.h:
../Core/Inc/tim.h:
../Core/Inc/usb.h:
../Core/Inc/gpio.h:
C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/pwm.h:
C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/App/error.h:
C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/app_relay.h:
C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv/app_current.h:
