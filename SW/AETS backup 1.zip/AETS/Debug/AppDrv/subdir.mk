################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../AppDrv/app_current.c \
../AppDrv/app_eeprom.c \
../AppDrv/app_relay.c \
../AppDrv/canfd.c \
../AppDrv/comuser.c \
../AppDrv/pwm.c 

OBJS += \
./AppDrv/app_current.o \
./AppDrv/app_eeprom.o \
./AppDrv/app_relay.o \
./AppDrv/canfd.o \
./AppDrv/comuser.o \
./AppDrv/pwm.o 

C_DEPS += \
./AppDrv/app_current.d \
./AppDrv/app_eeprom.d \
./AppDrv/app_relay.d \
./AppDrv/canfd.d \
./AppDrv/comuser.d \
./AppDrv/pwm.d 


# Each subdirectory must supply rules for building sources it contributes
AppDrv/%.o AppDrv/%.su AppDrv/%.cyclo: ../AppDrv/%.c AppDrv/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G474xx -DSTM32_THREAD_SAFE_STRATEGY=4 -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../Core/ThreadSafe -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv" -I"C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/App" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-AppDrv

clean-AppDrv:
	-$(RM) ./AppDrv/app_current.cyclo ./AppDrv/app_current.d ./AppDrv/app_current.o ./AppDrv/app_current.su ./AppDrv/app_eeprom.cyclo ./AppDrv/app_eeprom.d ./AppDrv/app_eeprom.o ./AppDrv/app_eeprom.su ./AppDrv/app_relay.cyclo ./AppDrv/app_relay.d ./AppDrv/app_relay.o ./AppDrv/app_relay.su ./AppDrv/canfd.cyclo ./AppDrv/canfd.d ./AppDrv/canfd.o ./AppDrv/canfd.su ./AppDrv/comuser.cyclo ./AppDrv/comuser.d ./AppDrv/comuser.o ./AppDrv/comuser.su ./AppDrv/pwm.cyclo ./AppDrv/pwm.d ./AppDrv/pwm.o ./AppDrv/pwm.su

.PHONY: clean-AppDrv

