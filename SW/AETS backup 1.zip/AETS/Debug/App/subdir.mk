################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../App/app_control.c \
../App/app_power.c \
../App/app_ui.c \
../App/commands.c \
../App/diagnostics.c \
../App/error.c \
../App/performance.c \
../App/utility.c 

OBJS += \
./App/app_control.o \
./App/app_power.o \
./App/app_ui.o \
./App/commands.o \
./App/diagnostics.o \
./App/error.o \
./App/performance.o \
./App/utility.o 

C_DEPS += \
./App/app_control.d \
./App/app_power.d \
./App/app_ui.d \
./App/commands.d \
./App/diagnostics.d \
./App/error.d \
./App/performance.d \
./App/utility.d 


# Each subdirectory must supply rules for building sources it contributes
App/%.o App/%.su App/%.cyclo: ../App/%.c App/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G474xx -DSTM32_THREAD_SAFE_STRATEGY=4 -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../Core/ThreadSafe -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/AppDrv" -I"C:/Users/user/Desktop/AETS_DIPLOMA_THESIS/automatedelectrictestingsystem_aets/SW/AETS/App" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-App

clean-App:
	-$(RM) ./App/app_control.cyclo ./App/app_control.d ./App/app_control.o ./App/app_control.su ./App/app_power.cyclo ./App/app_power.d ./App/app_power.o ./App/app_power.su ./App/app_ui.cyclo ./App/app_ui.d ./App/app_ui.o ./App/app_ui.su ./App/commands.cyclo ./App/commands.d ./App/commands.o ./App/commands.su ./App/diagnostics.cyclo ./App/diagnostics.d ./App/diagnostics.o ./App/diagnostics.su ./App/error.cyclo ./App/error.d ./App/error.o ./App/error.su ./App/performance.cyclo ./App/performance.d ./App/performance.o ./App/performance.su ./App/utility.cyclo ./App/utility.d ./App/utility.o ./App/utility.su

.PHONY: clean-App

