#ifndef APP_EEPROM_H
#define APP_EEPROM_H

#include "cmsis_os.h"

void StartEEPROMTask(void const * argument);
void app_eeprom_update_lifetime(void);

extern osThreadId eepromTaskHandle;

#endif // APP_EEPROM_H