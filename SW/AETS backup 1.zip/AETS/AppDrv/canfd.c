/*
 * canfd.c
 *
 *  Created on: Sep 22, 2023
 *      Author: Standa
 */

#include "canfd.h"
#include <stdint.h>
#include "stm32g4xx_hal.h"
#include "main.h"
#include <string.h>
#include <math.h>
#include "dac_ltc2633.h"
#include "leds.h"


extern FDCAN_HandleTypeDef hfdcan2;


#define CFD_SUPERLOOP_TX_PERIOD_MS		500
#define CFD_OUTPUT_MSG_ID				0xB00B5	//Extended ID


static uint32_t LastEvalTimeStamp = 0;
FDCAN_ProtocolStatusTypeDef CanProtStat = {0};
FDCAN_ErrorCountersTypeDef CanErrCntrs = {0};
static FDCAN_TxHeaderTypeDef TxHeader = {0};
uint8_t TxData[] = {0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80};


void cfd_Init(void){
	  TxHeader.Identifier = CFD_OUTPUT_MSG_ID;									// Prepare TX message structure
	  TxHeader.IdType = FDCAN_EXTENDED_ID;
	  TxHeader.TxFrameType = FDCAN_DATA_FRAME;
	  TxHeader.DataLength = FDCAN_DLC_BYTES_8;
	  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
	  TxHeader.BitRateSwitch = FDCAN_BRS_OFF;
	  TxHeader.FDFormat = FDCAN_CLASSIC_CAN;
	  TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
	  TxHeader.MessageMarker = 0;

	  HAL_FDCAN_Start(&hfdcan2);												// Start CAN peripheral

	  HAL_GPIO_WritePin(CAN_STB_GPIO_Port, CAN_STB_Pin, GPIO_PIN_RESET);		// Enable CAN transceiver
}






#define TXDATABITOFFSET_FREQ		0
#define TXDATABITOFFSET_LVL			32
#define TXDATABITOFFSET_ERR			48
#define TXDATABITOFFSET_UPCNTR		56


static float Freq_MHz = 0;
static uint16_t Level_Vpm_mA = 0;
static uint8_t UpCounter = 0;
static uint8_t Err = 0;


void UpdateTxBufferForCan(void){

	memcpy(TxData + TXDATABITOFFSET_FREQ/8, &Freq_MHz, 4);
	memcpy(TxData + TXDATABITOFFSET_LVL/8, &Level_Vpm_mA, 2);
	memcpy(TxData + TXDATABITOFFSET_ERR	/8, &Err, 2);
	memcpy(TxData + TXDATABITOFFSET_UPCNTR/8, &UpCounter, 1);
	UpCounter++;
}




void cfd_HandleCommunication(void){

	//static float SinArg = 0;
	//static int8_t Sign = 1;


	if(HAL_GetTick() >= LastEvalTimeStamp + CFD_SUPERLOOP_TX_PERIOD_MS){
		LastEvalTimeStamp = HAL_GetTick();

/*

		Freq_MHz = 10 + 5 * sinf(SinArg);
		SinArg += M_TWOPI / 20.0;
		if(SinArg > M_TWOPI) SinArg -= M_TWOPI;

		Level_Vpm_mA += Sign;
		if(Level_Vpm_mA >= 15){
			 Sign = -1;
			 dac_ltc2633_SetVoltage(dac_Td_ChB, 3500);
		}
		if(Level_Vpm_mA <= 5){
			 Sign = +1;
			 dac_ltc2633_SetVoltage(dac_Td_ChB, 500);
		}

*/

		HAL_FDCAN_GetProtocolStatus(&hfdcan2, &CanProtStat);
		HAL_FDCAN_GetErrorCounters(&hfdcan2, &CanErrCntrs);

		if(CanProtStat.BusOff){
			HAL_FDCAN_Stop(&hfdcan2);
			HAL_FDCAN_Start(&hfdcan2);												// Start CAN peripheral
		}

		UpdateTxBufferForCan();
		HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan2, &TxHeader, TxData);

		if(CanProtStat.LastErrorCode == 0)
			leds_Set(&leds_CAN);
		else
			leds_Reset(&leds_CAN);

	}
}

void setDiagnosticsByte(uint8_t diagStatus){
	Err = diagStatus;
}

void setCANValues(uint16_t disturbance, float lab_Frequency_MHz){
	Freq_MHz = lab_Frequency_MHz;
	Level_Vpm_mA = disturbance;

}
