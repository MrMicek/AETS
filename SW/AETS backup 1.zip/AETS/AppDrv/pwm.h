/*
 * pwm.h
 *
 *  Created on: Sep 16, 2025
 *      Author: Vojta
 */

#ifndef PWM_H_
#define PWM_H_
#include "error.h"



extern err_Td pwm_Init(void);
extern err_Td pwm_Set(int64_t frequencyKhz, float duty_cycle);
#endif /* PWM_H_ */
