/*
 * pwm.c
 *
 *  Created on: Sep 16, 2025
 *      Author: Vojta
 */
#include "pwm.h"
#include "stm32g4xx_hal.h"
#include "error.h"
#include "main.h"
#include "tim.h"
#include "utility.h"

#define TIMERS_CLK				144000000
#define DUTY_CYCLE_SENSITIVITY 	0.001385


err_Td pwm_Init(void){
	pwm_Set(0,0); //default hodnota
	if(HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_4) == HAL_OK){
		return err_Td_Ok;
	}
	else{
		return err_Td_NotValid;
	}

}

err_Td pwm_Set(int64_t frequencyKhz, float duty_cycle){
	int64_t arr_Value = (TIMERS_CLK / (frequencyKhz*1000))-1;
	__HAL_TIM_SET_AUTORELOAD(&htim5, arr_Value);//nastaveni ARR
	__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_4, (int32_t)((duty_cycle / 100.0f) * arr_Value));//nastaveni CRR
	HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_4);

	return err_Td_Ok;
}
