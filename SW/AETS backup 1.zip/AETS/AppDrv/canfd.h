/*
 * canfd.h
 *
 *  Created on: Sep 22, 2023
 *      Author: Standa
 */

#ifndef CANFD_H_
#define CANFD_H_
#include <stdint.h>

extern void cfd_Init(void);
extern void cfd_HandleCommunication(void);
extern void setDiagnosticsByte(uint8_t diagStatus);
extern void setCANValues(uint16_t disturbance, float lab_Frequency_MHz);
#endif /* CANFD_H_ */
