#ifndef APP_CURRENT_H
#define APP_CURRENT_H

#include "cmsis_os.h"
#include <stdint.h>

// --- Hardware and calculation constants for ACS724 with voltage divider ---
#define REFERENCE_VOLTAGE 3.3f
#define SENSOR_SUPPLY_VOLTAGE 5.0f
#define VOLTAGE_DIVIDER_RATIO 2.0f // Output is divided by 2 before ADC
#define ADC_RESOLUTION 4095.0f // 12-bit ADC
#define CURRENT_SENSOR_SENSITIVITY 0.8f // V/A for ACS724-2.5A
#define CURRENT_ZERO_VOLTAGE 2.5f // 0A = 2.5V at sensor output
#define ADC_ZERO_VOLTAGE 1.2391f // Measured voltage at ADC input for 0A
#define CURRENT_NUM_CHANNELS 4
#define ADC_SAMPLES 16 // Number of samples to average for current reading


void StartCurrentTask(void const * argument);
void app_current_prepare_test(void);
void app_current_monitor_test(void);
float app_current_read(uint8_t channel_idx);
float app_current_calculate(float adc_raw);
extern osThreadId currentTaskHandle;

#endif // APP_CURRENT_H