#include "app_current.h"
// Current sensing task: ADC reading, current monitoring
#include "cmsis_os.h"
#include "adc.h"
#include <stdio.h>
#include <stdint.h>
#include "utility.h"

// ADC channel mapping: channel_idx 0-3 -> {ADC1_IN9, ADC1_IN8, ADC1_IN7, ADC1_IN6}
// PC3, PC2, PC1, PC0
static uint32_t adc_channels[4] = {ADC_CHANNEL_9, ADC_CHANNEL_8, ADC_CHANNEL_7, ADC_CHANNEL_6};
static float adc_zero = 0.0f;

void app_current_prepare_test(void) {
    // Example: Start ADC conversion (simulate current sensor setup)
    HAL_ADC_Start(&hadc1); // Use ADC1, change as needed
}

void app_current_monitor_test(void) {
    // Example: Read ADC value and print (simulate current measurement)
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
    }
    HAL_ADC_Stop(&hadc1);
}

// Helper: Read and average ADC samples for a given channel
static uint32_t app_current_read_adc_averaged(ADC_HandleTypeDef* hadc, uint32_t channel) {
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = channel;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_640CYCLES_5; // Longest for best accuracy
#ifdef ADC_SINGLE_ENDED
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
#endif
#ifdef ADC_OFFSET_NONE
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
#endif
    if (HAL_ADC_ConfigChannel(hadc, &sConfig) != HAL_OK) {
        return 0;
    }
    uint32_t sum = 0;
    for (int i = 0; i < ADC_SAMPLES; i++) {
        if (HAL_ADC_Start(hadc) != HAL_OK) return 0;
        if (HAL_ADC_PollForConversion(hadc, HAL_MAX_DELAY) != HAL_OK) return 0;
        sum += HAL_ADC_GetValue(hadc);
        HAL_ADC_Stop(hadc);
        // Use HAL_Delay if scheduler not running, else osDelay
        if (osKernelRunning()) {
            osDelay(1);
        } else {
            HAL_Delay(1);
        }
    }
    return sum / ADC_SAMPLES;
}

float app_current_read(uint8_t channel_idx) {
    if (channel_idx >= 4) return 0;
    extern ADC_HandleTypeDef hadc1;
    uint32_t adc_raw = app_current_read_adc_averaged(&hadc1, adc_channels[channel_idx])+63;
    float v_adc = adc_raw * (REFERENCE_VOLTAGE / ADC_RESOLUTION);
    float v_sensor = v_adc * VOLTAGE_DIVIDER_RATIO;
    float current = UT_ABS((v_sensor - (ADC_ZERO_VOLTAGE * VOLTAGE_DIVIDER_RATIO)) / CURRENT_SENSOR_SENSITIVITY);
    return current;
}

float app_current_calculate(float adc_raw) {
    float v_adc = adc_raw * (REFERENCE_VOLTAGE / ADC_RESOLUTION);
    float v_sensor = v_adc * VOLTAGE_DIVIDER_RATIO;
    float current = -((v_sensor - (ADC_ZERO_VOLTAGE * VOLTAGE_DIVIDER_RATIO)) / CURRENT_SENSOR_SENSITIVITY);
    return current;
}
void StartCurrentTask(void const * argument) {
    // Start DMA once
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc1_buf, 2*ADC1_FRAME);

    for (;;) {
        if (adc1_half) { adc1_half = false; process_frame(&adc1_buf[0]); }
        if (adc1_full) { adc1_full = false; process_frame(&adc1_buf[ADC1_FRAME]); }
        osDelay(1);
    }
}
