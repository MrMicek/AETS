#ifndef APP_RELAY_H
#define APP_RELAY_H

#include "cmsis_os.h"
#include "gpio.h"
#include <stdint.h>

void StartRelayTask(void const * argument);
void app_relay_prepare_test(void);
void app_relay_run_test(void);
int app_relay_test_complete(void);
void app_relay_set(uint8_t relay_idx, GPIO_PinState state);
void app_relay_timed_sequence(uint8_t relay_idx, uint16_t num_periods, uint32_t on_time_ms, uint32_t off_time_ms);

extern osThreadId relayTaskHandle;

#endif // APP_RELAY_H