// Relay/MOSFET control task: switching, MUX, test execution
#include "app_relay.h"
#include "cmsis_os.h"
#include "gpio.h"
#include "performance.h"
#include <stdint.h>
#include <stdio.h>

// Relay mapping: relay_idx 0-3 -> {PC5, PB0, PB1, PB2}
static GPIO_TypeDef* relay_ports[4] = {GPIOC, GPIOB, GPIOB, GPIOB};
static uint16_t relay_pins[4] = {GPIO_PIN_5, GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2};

// Add static performance handles for relay ON/OFF timing
static perf_DurTd perf_RelayOn = {0};
static perf_DurTd perf_RelayOff = {0};

#define PERF_TICKS_TO_MS(ticks) ((ticks) / 1000)

void app_relay_set(uint8_t relay_idx, GPIO_PinState state) {
    if (relay_idx < 4) {
        HAL_GPIO_WritePin(relay_ports[relay_idx], relay_pins[relay_idx], state);
    }
}

void app_relay_prepare_test(void) {
    // Example: Set relay GPIO high (simulate relay ON)
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); // Change pin as needed
}

void app_relay_run_test(void) {
    // Example: Set relay GPIO low (simulate relay OFF)
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); // Change pin as needed
}

int app_relay_test_complete(void) {
    // TODO: Check if relay test is complete
    return 0;
}

void app_relay_timed_sequence(uint8_t relay_idx, uint16_t num_periods, uint32_t on_time_ms, uint32_t off_time_ms) {
    if (relay_idx >= 4) return;
    for (uint16_t i = 0; i < num_periods; i++) {
        // --- ON period timing ---
        perf_StartTmr(&perf_RelayOn);
        HAL_GPIO_WritePin(GPIOC, TRIGGER_OUT_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(relay_ports[relay_idx], relay_pins[relay_idx], GPIO_PIN_SET);
        DWT_Delay_ms(on_time_ms);
        HAL_GPIO_WritePin(GPIOC, TRIGGER_OUT_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(relay_ports[relay_idx], relay_pins[relay_idx], GPIO_PIN_RESET);
        perf_StopTmr(&perf_RelayOn);
        printf("Relay ON duration: %lu ticks, %lu ms\n", perf_RelayOn.LastDuration_Ticks, PERF_TICKS_TO_MS(perf_RelayOn.LastDuration_Ticks));

        // --- OFF period timing ---
        perf_StartTmr(&perf_RelayOff);
        HAL_GPIO_WritePin(GPIOC, TRIGGER_OUT_Pin, GPIO_PIN_SET);
        DWT_Delay_ms(off_time_ms);
        HAL_GPIO_WritePin(GPIOC, TRIGGER_OUT_Pin, GPIO_PIN_RESET);
        perf_StopTmr(&perf_RelayOff);
        printf("Relay OFF duration: %lu ticks, %lu ms\n", perf_RelayOff.LastDuration_Ticks, PERF_TICKS_TO_MS(perf_RelayOff.LastDuration_Ticks));
    }
}

void StartRelayTask(void const * argument)
{
    for(;;)
    {
        // TODO: Handle relay/MOSFET switching
        osDelay(20);
    }
}