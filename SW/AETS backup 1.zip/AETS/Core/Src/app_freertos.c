/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
// Task handles for all main tasks
osThreadId controlTaskHandle;
osThreadId uiTaskHandle;
osThreadId relayTaskHandle;
osThreadId currentTaskHandle;
osThreadId eepromTaskHandle;
osThreadId commTaskHandle;
osThreadId powerTaskHandle;
/* USER CODE END Variables */
osThreadId defaultTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

void StartBuzzerTask(void const * argument)
{
  pwm_Init();
  pwm_Set(5000, 50);
  HAL_Delay(2000);
  pwm_Set(0, 0);

  for (;;)
   {
     osDelay(1000);
   }
}

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* Create main application tasks */
  osThreadDef(controlTask, StartControlTask, osPriorityHigh, 0, 256);
  controlTaskHandle = osThreadCreate(osThread(controlTask), NULL);

  osThreadDef(uiTask, StartUITask, osPriorityNormal, 0, 256);
  uiTaskHandle = osThreadCreate(osThread(uiTask), NULL);

  osThreadDef(relayTask, StartRelayTask, osPriorityNormal, 0, 256);
  relayTaskHandle = osThreadCreate(osThread(relayTask), NULL);

  osThreadDef(currentTask, StartCurrentTask, osPriorityNormal, 0, 256);
  currentTaskHandle = osThreadCreate(osThread(currentTask), NULL);

  osThreadDef(eepromTask, StartEEPROMTask, osPriorityLow, 0, 256);
  eepromTaskHandle = osThreadCreate(osThread(eepromTask), NULL);

  osThreadDef(commTask, StartCommTask, osPriorityNormal, 0, 256);
  commTaskHandle = osThreadCreate(osThread(commTask), NULL);

  osThreadDef(powerTask, StartPowerTask, osPriorityHigh, 0, 128);
  powerTaskHandle = osThreadCreate(osThread(powerTask), NULL);
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

